import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Mori’s International | Copier Machine Spare Parts Manufacturer & Exporter',
  description: 'Mori’s International is a premier manufacturer and exporter of copier spare parts, toner cartridges, bulk toner powder, OPC drums, and fuser components based in Navi Mumbai near Nhava Sheva (JNPT) Port, India. Led by Director Jayesh Mori.',
  keywords: [
    'Copier Machine Spare Parts',
    'Copier Parts Exporter India',
    'OPC Drum Manufacturer',
    'Fuser Roller Supplier',
    'Toner Cartridge Exporter',
    'Duplicator Inks Riso Duplo',
    'Mori’s International',
    'Jayesh Mori',
    'Nhava Sheva Port Exporter',
    'Canon Ricoh Konica Minolta Kyocera Spares',
  ],
  authors: [{ name: 'Jayesh Mori - Director' }],
  openGraph: {
    title: 'Mori’s International | Copier Machine Spare Parts Manufacturer & Exporter',
    description: 'Quality Products, Reliable Supply and Global Business Solutions. Near Nhava Sheva (JNPT) Container Port, Navi Mumbai, India.',
    type: 'website',
    locale: 'en_US',
    siteName: 'Mori’s International',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Mori’s International | Copier Machine Spare Parts Manufacturer & Exporter',
    description: 'Quality Products, Reliable Supply and Global Business Solutions. Global shipping for digital copier components.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  // Structured Data (JSON-LD) for B2B Export Manufacturer
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Corporation',
    name: "Mori's International",
    legalName: "MORI'S INTERNATIONAL",
    url: 'https://ais-dev-l53ltlddyr6t6stotypaty-80806885273.asia-southeast1.run.app',
    founder: {
      '@type': 'Person',
      name: 'Jayesh Mori',
      jobTitle: 'Director',
    },
    description:
      'Copier Machine Spare Parts Manufacturer & Exporter based in Navi Mumbai, India near Nhava Sheva (JNPT) Port.',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Shop No. 1-2-3, Patel Harmony, Plot No. 23, Sector 20, Kamothe, Panvel',
      addressLocality: 'Navi Mumbai',
      addressRegion: 'Maharashtra',
      postalCode: '410209',
      addressCountry: 'IN',
    },
    telephone: ['+919082523625', '+917208334310'],
    email: 'morisinternationalindia@gmail.com',
  };

  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className="bg-white text-slate-900 antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
