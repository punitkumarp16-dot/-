'use client';

import React, { useState } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { BrandLogos } from '@/components/BrandLogos';
import { FeaturedCategories } from '@/components/FeaturedCategories';
import { ProductCatalog } from '@/components/ProductCatalog';
import { WhyChooseUs } from '@/components/WhyChooseUs';
import { AboutUs } from '@/components/AboutUs';
import { ContactSection } from '@/components/ContactSection';
import { Footer } from '@/components/Footer';
import { QuoteDrawer } from '@/components/QuoteDrawer';
import { EnquiriesViewer } from '@/components/EnquiriesViewer';
import { Product, QuoteItem, CompatibleBrand, ProductCategory } from '@/types';
import { MessageCircle, Database } from 'lucide-react';
import { createWhatsAppUrl } from '@/data/company';

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [quoteItems, setQuoteItems] = useState<QuoteItem[]>([]);
  const [isQuoteDrawerOpen, setIsQuoteDrawerOpen] = useState(false);
  const [isEnquiriesViewerOpen, setIsEnquiriesViewerOpen] = useState(false);

  // Add product to quote basket
  const handleAddToQuote = (product: Product, quantity: number = 1) => {
    setQuoteItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    setIsQuoteDrawerOpen(true);
  };

  // Direct single-product quote request
  const handleDirectQuote = (product: Product) => {
    setQuoteItems((prev) => {
      const exists = prev.find((item) => item.product.id === product.id);
      if (!exists) {
        return [...prev, { product, quantity: 1 }];
      }
      return prev;
    });
    setIsQuoteDrawerOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    setQuoteItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setQuoteItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearQuote = () => {
    setQuoteItems([]);
  };

  const scrollToProducts = () => {
    const el = document.getElementById('products');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white antialiased">
      {/* 1. Header (3-Zone Top Bar Contract) */}
      <Header
        quoteCount={quoteItems.reduce((acc, curr) => acc + curr.quantity, 0)}
        onOpenQuote={() => setIsQuoteDrawerOpen(true)}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero
          onExploreProducts={scrollToProducts}
          onRequestQuote={() => setIsQuoteDrawerOpen(true)}
        />

        {/* 3. Compatible Brands Showcase */}
        <BrandLogos
          onSelectBrand={(brand: CompatibleBrand) => {
            setSelectedBrand(brand);
            setSelectedCategory('all');
          }}
        />

        {/* 4. Featured Product Categories */}
        <FeaturedCategories
          onSelectCategory={(category: ProductCategory) => {
            setSelectedCategory(category);
            setSelectedBrand('all');
          }}
        />

        {/* 5. Product Search & Filter System + Catalogue */}
        <ProductCatalog
          selectedCategory={selectedCategory}
          selectedBrand={selectedBrand}
          onCategoryChange={setSelectedCategory}
          onBrandChange={setSelectedBrand}
          onAddToQuote={handleAddToQuote}
          onDirectQuote={handleDirectQuote}
          quoteItems={quoteItems}
        />

        {/* 6. Why Choose Us (6 Feature Cards) */}
        <WhyChooseUs />

        {/* 7. About Us (Director Jayesh Mori, Navi Mumbai & JNPT port advantage) */}
        <AboutUs />

        {/* 8. Contact Section (Official address, phones, WhatsApp, maps) */}
        <ContactSection />
      </main>

      {/* 9. Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setSelectedBrand('all');
        }}
      />

      {/* Quotation Request Drawer */}
      <QuoteDrawer
        isOpen={isQuoteDrawerOpen}
        onClose={() => setIsQuoteDrawerOpen(false)}
        items={quoteItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearQuote={handleClearQuote}
        onAddProduct={handleAddToQuote}
      />

      {/* Director Inquiries Database Viewer Modal */}
      <EnquiriesViewer
        isOpen={isEnquiriesViewerOpen}
        onClose={() => setIsEnquiriesViewerOpen(false)}
      />

      {/* Floating Action Controls on Bottom Corner */}
      <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2.5">
        {/* Discrete Admin Database Portal */}
        <button
          onClick={() => setIsEnquiriesViewerOpen(true)}
          type="button"
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 hover:bg-slate-900 text-slate-300 hover:text-white rounded-full text-[11px] shadow-lg border border-slate-700 backdrop-blur-xs transition-colors cursor-pointer"
          title="Review saved export inquiries in backend database"
        >
          <Database className="w-3.5 h-3.5 text-sky-400" />
          <span>Inquiries Admin</span>
        </button>

        {/* Floating WhatsApp Quick Action Button */}
        <a
          href={createWhatsAppUrl('Hello Jayesh Mori, I am visiting your website and have an urgent inquiry about copier spare parts.')}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-xl hover:shadow-2xl transition-all duration-200 group cursor-pointer"
          aria-label="Direct WhatsApp Chat with Director Jayesh Mori"
        >
          <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-xs font-bold tracking-tight">WhatsApp Us</span>
        </a>
      </div>
    </div>
  );
}
