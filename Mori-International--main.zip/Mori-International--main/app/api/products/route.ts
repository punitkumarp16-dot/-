import { NextRequest, NextResponse } from 'next/server';
import { PRODUCTS_CATALOG } from '@/data/products';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get('search')?.toLowerCase() || '';
  const brand = searchParams.get('brand') || 'all';
  const category = searchParams.get('category') || 'all';

  let filtered = [...PRODUCTS_CATALOG];

  if (brand !== 'all') {
    filtered = filtered.filter((p) => p.brand.toLowerCase() === brand.toLowerCase());
  }

  if (category !== 'all') {
    filtered = filtered.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }

  if (search) {
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(search) ||
        p.code.toLowerCase().includes(search) ||
        p.compatibleModels.some((m) => m.toLowerCase().includes(search)) ||
        p.description.toLowerCase().includes(search)
    );
  }

  return NextResponse.json({
    success: true,
    total: filtered.length,
    products: filtered,
  });
}
