import { NextRequest, NextResponse } from 'next/server';
import { getEnquiries, saveEnquiry } from '@/lib/storage';
import { EnquirySubmission } from '@/types';

export async function GET() {
  try {
    const enquiries = getEnquiries();
    return NextResponse.json({ success: true, count: enquiries.length, enquiries });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch enquiries' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      customerName,
      companyName,
      email,
      phone,
      country,
      shippingTerm,
      message,
      items,
    } = body;

    // Validation
    if (!customerName || !email || !phone) {
      return NextResponse.json(
        { success: false, error: 'Name, email, and contact number are required' },
        { status: 400 }
      );
    }

    const id = `MI-RFQ-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newEnquiry: EnquirySubmission = {
      id,
      customerName: String(customerName).trim(),
      companyName: String(companyName || 'Individual Trader').trim(),
      email: String(email).trim(),
      phone: String(phone).trim(),
      country: String(country || 'Not specified').trim(),
      shippingTerm: shippingTerm || 'FOB Nhava Sheva (JNPT)',
      message: String(message || '').trim(),
      items: Array.isArray(items) ? items : [],
      createdAt: new Date().toISOString(),
      status: 'New',
    };

    saveEnquiry(newEnquiry);

    return NextResponse.json({
      success: true,
      message: 'Quotation request successfully received by MORI’S INTERNATIONAL.',
      enquiryId: id,
      enquiry: newEnquiry,
    });
  } catch (error) {
    console.error('Error handling enquiry POST:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error while processing request' },
      { status: 500 }
    );
  }
}
