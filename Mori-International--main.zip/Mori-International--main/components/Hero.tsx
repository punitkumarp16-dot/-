'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, FileText, PhoneCall, Ship, CheckCircle2 } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

interface HeroProps {
  onExploreProducts: () => void;
  onRequestQuote: () => void;
}

export function Hero({ onExploreProducts, onRequestQuote }: HeroProps) {
  return (
    <section className="relative bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white overflow-hidden py-14 sm:py-20 lg:py-24">
      {/* Subtle grid pattern overlay */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Proposition and Actions */}
          <div className="lg:col-span-7 space-y-6">
            {/* Context kicker: Zero-pill discipline */}
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wide text-sky-400 uppercase">
              <span>Manufacturer & Exporter</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Navi Mumbai, India</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Global Supply</span>
            </div>

            {/* Headline with text-wrap: balance */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-bold tracking-tight text-white leading-tight [text-wrap:balance]">
              Your Trusted Partner in Copier Machine Spare Parts
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Quality Products, Reliable Supply and Global Business Solutions. Supplying precision OPC drums, fuser rollers, toner powder, and consumable components for digital copiers and duplicators worldwide.
            </p>

            {/* Strategic Logistics Anchor */}
            <div className="flex items-center gap-3 p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-xs sm:text-sm text-slate-200">
              <div className="p-2 bg-blue-600/30 text-sky-400 rounded-lg shrink-0">
                <Ship className="w-5 h-5" />
              </div>
              <div>
                <span className="font-semibold text-white">Direct Export Logistics Advantage: </span>
                <span className="text-slate-300">
                  Headquartered in Kamothe, Navi Mumbai, immediately adjacent to Jawaharlal Nehru Port Trust (JNPT / Nhava Sheva) — expedited container dispatch and air cargo to Middle East, Africa, Europe & the Americas.
                </span>
              </div>
            </div>

            {/* Key Offerings List */}
            <div className="grid grid-cols-2 gap-2.5 pt-1 text-xs sm:text-sm text-slate-300">
              {COMPANY_DETAILS.keyOfferings.map((offering) => (
                <div key={offering} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>{offering}</span>
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <button
                onClick={onExploreProducts}
                type="button"
                className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-md transition-all cursor-pointer"
              >
                <span>Explore Products</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onRequestQuote}
                type="button"
                className="flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-md transition-all cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Request a Quote</span>
              </button>

              <a
                href="#contact"
                className="flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-lg transition-all"
              >
                <PhoneCall className="w-4 h-4 text-sky-400" />
                <span>Contact Us</span>
              </a>
            </div>
          </div>

          {/* Right Column: Visual Anchor */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-800 shadow-2xl">
              <div className="relative aspect-[4/3] w-full">
                <Image
                  src="/images/hero_copier_parts_export_1794149100838.jpg"
                  alt="Precision copier machine spare parts manufactured and exported by Mori's International"
                  fill
                  sizes="(max-width: 1024px) 100vw, 45vw"
                  className="object-cover"
                  priority
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Clean caption bar */}
              <div className="p-4 bg-slate-900/95 border-t border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white">Export Quality Assured</span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    Tested for Canon, Ricoh, Konica Minolta, Kyocera, Xerox & Toshiba
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-amber-400 font-medium">Jayesh Mori</span>
                  <p className="text-slate-500 text-[11px]">Director</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
