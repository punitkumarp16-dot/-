'use client';

import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, Send, MessageCircle, CheckCircle, Package, AlertCircle } from 'lucide-react';
import { QuoteItem, Product } from '@/types';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

interface QuoteDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: QuoteItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearQuote: () => void;
  onAddProduct: (product: Product) => void;
}

export function QuoteDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearQuote,
}: QuoteDrawerProps) {
  const [customerName, setCustomerName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [shippingTerm, setShippingTerm] = useState<'FOB Nhava Sheva (JNPT)' | 'CIF (Destination Port)' | 'Air Express' | 'Domestic Supply (India)'>('FOB Nhava Sheva (JNPT)');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Format the quotation message for WhatsApp
  const generateWhatsAppMessage = () => {
    let text = `*QUOTATION REQUEST - MORI'S INTERNATIONAL*\n\n`;
    text += `*Customer:* ${customerName || 'B2B Buyer'}\n`;
    if (companyName) text += `*Company:* ${companyName}\n`;
    text += `*Contact Phone:* ${phone || 'Not provided'}\n`;
    if (email) text += `*Email:* ${email}\n`;
    if (country) text += `*Destination Country / Port:* ${country}\n`;
    text += `*Shipping Term:* ${shippingTerm}\n\n`;

    if (items.length > 0) {
      text += `*Requested Spare Parts / Products (${items.length}):*\n`;
      items.forEach((item, idx) => {
        text += `${idx + 1}. [${item.product.code}] ${item.product.name} (${item.product.brand})\n`;
        text += `   Qty: ${item.quantity} | MOQ: ${item.product.moq}\n`;
      });
      text += `\n`;
    } else {
      text += `*Inquiry:* General catalogue pricing & availability\n\n`;
    }

    if (message.trim()) {
      text += `*Additional Notes / Machine Models:*\n${message.trim()}\n\n`;
    }

    text += `_Sent via Mori's International Official Web Portal_`;
    return text;
  };

  const handleWhatsAppSend = () => {
    if (!phone && !customerName) {
      // Prompt user or still open with available data
    }
    const waUrl = createWhatsAppUrl(generateWhatsAppMessage(), '919082523625');
    window.open(waUrl, '_blank');
  };

  const handleSubmitEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!customerName.trim() || !email.trim() || !phone.trim()) {
      setErrorMessage('Please fill in your name, email, and WhatsApp/phone number.');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName,
          companyName,
          email,
          phone,
          country,
          shippingTerm,
          message,
          items: items.map((i) => ({
            code: i.product.code,
            name: i.product.name,
            brand: i.product.brand,
            quantity: i.quantity,
          })),
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSubmittedId(data.enquiryId);
        onClearQuote();
      } else {
        setErrorMessage(data.error || 'Failed to submit quotation. Please try again.');
      }
    } catch (err) {
      setErrorMessage('An unexpected error occurred. Please contact us directly via WhatsApp.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-xl bg-white h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-sky-400" />
            <div>
              <h2 className="text-base font-bold tracking-tight">
                Request for Quotation (RFQ)
              </h2>
              <p className="text-xs text-slate-400">
                Direct export inquiry to Director Jayesh Mori
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            aria-label="Close quote drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {submittedId ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Quotation Request Submitted!
              </h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Thank you, <strong className="text-slate-900">{customerName}</strong>. Your export inquiry has been logged in our system with Reference ID:
              </p>
              <div className="inline-block px-4 py-2 bg-slate-100 border border-slate-200 rounded-lg text-sm font-mono font-bold text-blue-700">
                {submittedId}
              </div>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Director Jayesh Mori and our export logistics team will review your quantities and respond within 2-4 business hours with FOB/CIF pricing.
              </p>

              <div className="pt-4 flex flex-col gap-2 max-w-xs mx-auto">
                <button
                  type="button"
                  onClick={handleWhatsAppSend}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Follow-up on WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSubmittedId(null);
                    onClose();
                  }}
                  className="w-full py-2 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Done & Continue Browsing
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Product List Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Selected Spare Parts ({items.length})
                  </h3>
                  {items.length > 0 && (
                    <button
                      type="button"
                      onClick={onClearQuote}
                      className="text-[11px] text-red-600 hover:text-red-700 font-medium cursor-pointer"
                    >
                      Clear All
                    </button>
                  )}
                </div>

                {items.length === 0 ? (
                  <div className="p-4 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center">
                    <p className="text-xs text-slate-500">
                      Your RFQ basket is currently empty.
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      You can add specific items from the product catalogue, or submit a general inquiry below.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                    {items.map((item) => (
                      <div
                        key={item.product.id}
                        className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[10px] text-slate-500 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                              {item.product.code}
                            </span>
                            <span className="font-semibold text-blue-700">{item.product.brand}</span>
                          </div>
                          <div className="font-medium text-slate-800 truncate mt-0.5">
                            {item.product.name}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            MOQ: {item.product.moq}
                          </div>
                        </div>

                        {/* Quantity Stepper */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                            className="p-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 cursor-pointer"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center font-bold text-slate-900 tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="p-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 cursor-pointer"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onRemoveItem(item.product.id)}
                            className="p-1 text-slate-400 hover:text-red-600 rounded ml-1 cursor-pointer"
                            title="Remove part from RFQ"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Inquiry Form */}
              <form onSubmit={handleSubmitEnquiry} className="space-y-3.5 border-t border-slate-100 pt-4">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Buyer & Company Details
                </h3>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ahmed Al-Mansoor"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Company / Trading Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Apex Copier Supplies LLC"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Business Email *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="buyer@company.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      WhatsApp / Phone (with code) *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+971 50 123 4567"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Destination Country / Port
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Dubai, Jebel Ali / Nairobi"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Preferred Shipping Term
                    </label>
                    <select
                      value={shippingTerm}
                      onChange={(e) => setShippingTerm(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      <option value="FOB Nhava Sheva (JNPT)">FOB Nhava Sheva (JNPT)</option>
                      <option value="CIF (Destination Port)">CIF (Destination Port)</option>
                      <option value="Air Express">Air Express (DHL/FedEx)</option>
                      <option value="Domestic Supply (India)">Domestic Supply (India)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Special Inquiries / Machine Models
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide specific part numbers, annual consumption, or custom packaging requirements..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 resize-none"
                  />
                </div>

                {/* Submit Actions */}
                <div className="pt-2 space-y-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-sky-200" />
                    <span>{isSubmitting ? 'Submitting Quotation Request...' : 'Submit Quotation Request'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleWhatsAppSend}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Instant Inquiry via WhatsApp (+91 90825 23625)</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                  No payment or checkout required. All inquiries are quoted directly on FOB Nhava Sheva or CIF terms by Director Jayesh Mori.
                </p>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
