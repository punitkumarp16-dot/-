'use client';

import React from 'react';
import { ShieldCheck, Boxes, Coins, Truck, Anchor, Headphones, Check } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

export function WhyChooseUs() {
  const features = [
    {
      title: 'Quality Products',
      description: 'Strict optical density testing, coating friction verification, and thermal endurance checks ensure all OPC drums, rollers, and blades deliver OEM-matching longevity.',
      icon: <ShieldCheck className="w-6 h-6 text-sky-600" />,
      points: ['Japanese-grade OPC coatings', 'Consistent CMYK toner formulation', 'Zero-defect manufacturing standards'],
    },
    {
      title: 'Wide Product Range',
      description: 'A comprehensive one-stop inventory covering all critical consumables and mechanical replacement parts for Canon, Ricoh, Konica Minolta, Kyocera, Xerox, Toshiba, Riso, and Duplo.',
      icon: <Boxes className="w-6 h-6 text-blue-600" />,
      points: ['9 complete product categories', 'Over 500+ compatible machine models', 'Consolidated mixed container packing'],
    },
    {
      title: 'Competitive Pricing',
      description: 'Direct manufacturer and bulk exporter pricing models engineered to give wholesale distributors, repair workshops, and reconditioners healthy profit margins.',
      icon: <Coins className="w-6 h-6 text-amber-500" />,
      points: ['Transparent factory export rates', 'Volume tiered bulk discounts', 'Direct export without middlemen markups'],
    },
    {
      title: 'Reliable Supply',
      description: 'Continuous inventory buffering for high-moving drum units, toner cartridges, and fuser sleeves to prevent downtime for commercial printing operations.',
      icon: <Truck className="w-6 h-6 text-emerald-600" />,
      points: ['Ready warehouse stock in Navi Mumbai', 'Batch tracking and stable replenishment', 'Quick order turnaround'],
    },
    {
      title: 'Export Support',
      description: 'Strategic proximity to Jawaharlal Nehru Port Trust (JNPT / Nhava Sheva) enables seamless ocean container freight, customs documentation, and worldwide air cargo dispatch.',
      icon: <Anchor className="w-6 h-6 text-indigo-600" />,
      points: ['Near JNPT container port', 'Seaworthy moisture-barrier packaging', 'FOB, CIF & door-to-port logistics guidance'],
    },
    {
      title: 'Customer Assistance',
      description: 'Direct technical consultation with Director Jayesh Mori and our experienced parts specialists to verify machine model compatibility and part specifications before dispatch.',
      icon: <Headphones className="w-6 h-6 text-rose-600" />,
      points: ['Direct WhatsApp line with management', 'Model compatibility verification', 'Dedicated pre- and post-shipment support'],
    },
  ];

  return (
    <section id="why-us" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">
            The Mori’s International Advantage
          </div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
            Why Global Importers Partner With Us
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Delivering precision copier machine spare parts, dependable container shipments, and honest business relationships from Navi Mumbai to partners worldwide.
          </p>
        </div>

        {/* 6 Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="p-6 bg-slate-50/70 hover:bg-white border border-slate-200 hover:border-blue-300 rounded-xl transition-all duration-200 hover:shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-white border border-slate-200/80 shadow-2xs flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {feature.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200/60 space-y-1.5 text-[11px] text-slate-700 font-medium">
                {feature.points.map((pt) => (
                  <div key={pt} className="flex items-center gap-2">
                    <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
