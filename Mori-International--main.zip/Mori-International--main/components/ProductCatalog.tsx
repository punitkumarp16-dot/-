'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { Search, Filter, RotateCcw, Plus, Check, FileText, Info, Layers, Eye } from 'lucide-react';
import { Product, ProductCategory, CompatibleBrand } from '@/types';
import { PRODUCTS_CATALOG } from '@/data/products';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

interface ProductCatalogProps {
  selectedCategory: string;
  selectedBrand: string;
  onCategoryChange: (cat: string) => void;
  onBrandChange: (brand: string) => void;
  onAddToQuote: (product: Product, quantity?: number) => void;
  onDirectQuote: (product: Product) => void;
  quoteItems: Array<{ product: Product; quantity: number }>;
}

export function ProductCatalog({
  selectedCategory,
  selectedBrand,
  onCategoryChange,
  onBrandChange,
  onAddToQuote,
  onDirectQuote,
  quoteItems,
}: ProductCatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [modelFilter, setModelFilter] = useState('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Extract all unique machine models for the model filter
  const allModels = useMemo(() => {
    const set = new Set<string>();
    PRODUCTS_CATALOG.forEach((p) => {
      p.compatibleModels.forEach((m) => set.add(m));
    });
    return Array.from(set).sort();
  }, []);

  // Filtered products calculation
  const filteredProducts = useMemo(() => {
    return PRODUCTS_CATALOG.filter((p) => {
      // Category match
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      // Brand match
      if (selectedBrand !== 'all' && p.brand !== selectedBrand) {
        return false;
      }
      // Model match
      if (modelFilter && !p.compatibleModels.some((m) => m.toLowerCase().includes(modelFilter.toLowerCase()))) {
        return false;
      }
      // Search query match (name, code, description, compatible models)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesCode = p.code.toLowerCase().includes(q);
        const matchesDesc = p.description.toLowerCase().includes(q);
        const matchesModels = p.compatibleModels.some((m) => m.toLowerCase().includes(q));
        if (!matchesName && !matchesCode && !matchesDesc && !matchesModels) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCategory, selectedBrand, modelFilter, searchQuery]);

  const handleResetFilters = () => {
    onCategoryChange('all');
    onBrandChange('all');
    setModelFilter('');
    setSearchQuery('');
  };

  const isItemInQuote = (productId: string) => {
    return quoteItems.some((item) => item.product.id === productId);
  };

  return (
    <section id="products" className="py-16 bg-slate-50/60 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-1">
              Export Catalogue & Specifications
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Copier Machine Spare Parts Catalogue
            </h2>
          </div>
          <div className="text-xs text-slate-600">
            Showing <span className="font-bold text-slate-900 tabular-nums">{filteredProducts.length}</span> of{' '}
            <span className="font-bold text-slate-900 tabular-nums">{PRODUCTS_CATALOG.length}</span> verified export items
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs mb-8 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search by Product Name or Code */}
            <div className="md:col-span-5 relative">
              <label htmlFor="search-input" className="sr-only">Search parts or codes</label>
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  id="search-input"
                  type="text"
                  placeholder="Search by part name or code (e.g. OPC, 4225, C364)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            {/* Filter by Category */}
            <div className="md:col-span-3">
              <label htmlFor="category-select" className="sr-only">Filter by Category</label>
              <select
                id="category-select"
                value={selectedCategory}
                onChange={(e) => onCategoryChange(e.target.value)}
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="all">All Categories (9)</option>
                {COMPANY_DETAILS.categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Filter by Brand */}
            <div className="md:col-span-2">
              <label htmlFor="brand-select" className="sr-only">Filter by Brand</label>
              <select
                id="brand-select"
                value={selectedBrand}
                onChange={(e) => onBrandChange(e.target.value)}
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="all">All Brands (8)</option>
                {COMPANY_DETAILS.compatibleBrands.map((b) => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Filter by Machine Model or Reset */}
            <div className="md:col-span-2 flex items-center gap-2">
              <input
                type="text"
                placeholder="Model (e.g. 2520)"
                value={modelFilter}
                onChange={(e) => setModelFilter(e.target.value)}
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button
                type="button"
                onClick={handleResetFilters}
                title="Reset all search filters"
                className="p-2.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg shrink-0 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Category Segmented Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-t border-slate-100 pt-3">
            <span className="text-slate-400 text-xs shrink-0 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Quick Filter:
            </span>
            <button
              onClick={() => onCategoryChange('all')}
              className={`px-3 py-1 rounded-md whitespace-nowrap shrink-0 transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-slate-900 text-white font-medium'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Items
            </button>
            {COMPANY_DETAILS.categories.map((c) => (
              <button
                key={c}
                onClick={() => onCategoryChange(c)}
                className={`px-3 py-1 rounded-md whitespace-nowrap shrink-0 transition-colors ${
                  selectedCategory === c
                    ? 'bg-blue-700 text-white font-medium'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
            <div className="w-12 h-12 mx-auto mb-3 text-slate-400 flex items-center justify-center bg-slate-100 rounded-full">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">No matching spare parts found</h3>
            <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
              Try adjusting your search query, selecting &ldquo;All Categories&rdquo;, or contacting Director Jayesh Mori directly for custom sourcing.
            </p>
            <div className="mt-5 flex justify-center gap-3">
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
              <a
                href={createWhatsAppUrl(`Hello Jayesh Mori, I am looking for a copier spare part not listed: ${searchQuery}`)}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
              >
                Inquire on WhatsApp
              </a>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => {
              const inQuote = isItemInQuote(product.id);

              return (
                <div
                  key={product.id}
                  className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between"
                >
                  {/* Card Top: Image & Status */}
                  <div>
                    <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden group">
                      <Image
                        src={product.image}
                        alt={product.name}
                        fill
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                        className="object-cover group-hover:scale-103 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      {/* Zero-pill subtle metadata in corner */}
                      <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-xs text-white text-[11px] font-mono px-2 py-0.5 rounded">
                        {product.code}
                      </div>

                      {/* Quick view button */}
                      <button
                        type="button"
                        onClick={() => setQuickViewProduct(product)}
                        className="absolute bottom-3 right-3 p-2 bg-white/90 hover:bg-white text-slate-800 rounded-lg shadow-sm transition-all opacity-90 hover:opacity-100 cursor-pointer"
                        title="Quick view product specs"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Content Section */}
                    <div className="p-5 space-y-3">
                      {/* Clean metadata line without pill badge sandwich */}
                      <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                        <span className="text-blue-700 font-semibold">{product.brand}</span>
                        <span aria-hidden="true" className="text-slate-300">·</span>
                        <span>{product.category}</span>
                        <span aria-hidden="true" className="text-slate-300">·</span>
                        <span className="text-emerald-700 font-medium">{product.status}</span>
                      </div>

                      <h3 className="text-base font-bold text-slate-900 leading-snug line-clamp-2">
                        {product.name}
                      </h3>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {product.description}
                      </p>

                      {/* Compatible Models Box */}
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                        <span className="font-semibold text-slate-700 block mb-1">
                          Compatible Machine Models:
                        </span>
                        <p className="text-slate-600 line-clamp-2 text-[11px] font-mono">
                          {product.compatibleModels.join(', ')}
                        </p>
                      </div>

                      {/* Packaging & MOQ */}
                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                        <span>MOQ: <strong className="text-slate-800">{product.moq}</strong></span>
                        <span className="truncate max-w-[170px]" title={product.packaging}>
                          {product.packaging}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Card Actions: Request Quote & Add to RFQ */}
                  <div className="p-5 pt-0 grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onAddToQuote(product, 1)}
                      className={`flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                        inQuote
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-200'
                      }`}
                    >
                      {inQuote ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>In RFQ List</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5 text-slate-600" />
                          <span>Add to RFQ</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => onDirectQuote(product)}
                      className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5 text-sky-200" />
                      <span>Request Quote</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Quick View Modal */}
        {quickViewProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
              <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                <div>
                  <span className="text-xs font-semibold text-blue-700 uppercase">
                    {quickViewProduct.brand} · {quickViewProduct.category}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 mt-1">
                    {quickViewProduct.name}
                  </h3>
                  <p className="text-xs font-mono text-slate-500 mt-0.5">Code: {quickViewProduct.code}</p>
                </div>
                <button
                  onClick={() => setQuickViewProduct(null)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 my-5">
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
                  <Image
                    src={quickViewProduct.image}
                    alt={quickViewProduct.name}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <h4 className="font-semibold text-slate-900">Technical Description</h4>
                    <p className="text-slate-600 mt-1 leading-relaxed">
                      {quickViewProduct.description}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900">Key Engineering Features</h4>
                    <ul className="list-disc list-inside space-y-1 text-slate-600 mt-1">
                      {quickViewProduct.keyFeatures.map((f) => (
                        <li key={f}>{f}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1">
                    <p><strong className="text-slate-800">Minimum Order Qty:</strong> {quickViewProduct.moq}</p>
                    <p><strong className="text-slate-800">Export Packaging:</strong> {quickViewProduct.packaging}</p>
                    <p><strong className="text-slate-800">Supply Status:</strong> {quickViewProduct.status}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-900 mb-1">Compatible Machine Models:</h4>
                <div className="flex flex-wrap gap-1.5">
                  {quickViewProduct.compatibleModels.map((m) => (
                    <span key={m} className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs font-mono rounded">
                      {m}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    onAddToQuote(quickViewProduct, 1);
                    setQuickViewProduct(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
                >
                  Add to RFQ List
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const prod = quickViewProduct;
                    setQuickViewProduct(null);
                    onDirectQuote(prod);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  Request Quotation Now
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
