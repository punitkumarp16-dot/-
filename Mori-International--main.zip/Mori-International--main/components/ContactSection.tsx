'use client';

import React, { useState } from 'react';
import { MapPin, Phone, Mail, MessageCircle, Send, CheckCircle2, Clock, Globe, Anchor, ExternalLink } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

export function ContactSection() {
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submittedRef, setSubmittedRef] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!name.trim() || !email.trim() || !phone.trim()) {
      setFormError('Please enter your name, email, and phone number.');
      return;
    }

    setSubmitting(true);

    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name,
          companyName: company,
          email,
          phone,
          country,
          shippingTerm: 'FOB Nhava Sheva (JNPT)',
          message,
          items: [],
        }),
      });

      const data = await res.json();
      if (data.success) {
        setSubmittedRef(data.enquiryId);
        setName('');
        setCompany('');
        setEmail('');
        setPhone('');
        setCountry('');
        setMessage('');
      } else {
        setFormError(data.error || 'Failed to submit message.');
      }
    } catch (err) {
      setFormError('Submission failed. Please use the direct WhatsApp button.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">
            Direct Global Export Inquiries
          </div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
            Contact MORI’S INTERNATIONAL
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Connect with Director Jayesh Mori and our export logistics department. We welcome distributors, wholesalers, and fleet reconditioners from across the globe.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Official Contact Details & Click-to-Call */}
          <div className="lg:col-span-5 space-y-6">
            {/* Headquarters Card */}
            <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl shadow-2xs space-y-5">
              <h3 className="text-base font-bold text-slate-900 border-b border-slate-200 pb-3">
                Official Company Information
              </h3>

              <div className="space-y-4 text-xs">
                {/* Physical Address */}
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-100 text-blue-700 rounded-lg shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-0.5">Corporate & Warehouse Address</h4>
                    <p className="text-slate-700 font-medium">MORI’S INTERNATIONAL</p>
                    <p className="text-slate-600">{COMPANY_DETAILS.address.line1},</p>
                    <p className="text-slate-600">{COMPANY_DETAILS.address.line2},</p>
                    <p className="text-slate-600">
                      {COMPANY_DETAILS.address.city} – {COMPANY_DETAILS.address.zip}, {COMPANY_DETAILS.address.state}, {COMPANY_DETAILS.address.country}.
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5 text-blue-700 font-semibold text-[11px]">
                      <Anchor className="w-3.5 h-3.5 shrink-0" />
                      <span>{COMPANY_DETAILS.address.landmark}</span>
                    </div>
                  </div>
                </div>

                {/* Director Profile */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200">
                  <div className="p-2 bg-amber-100 text-amber-700 rounded-lg shrink-0 mt-0.5">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-0.5">Executive Management</h4>
                    <p className="text-slate-700 font-medium">{COMPANY_DETAILS.director} – {COMPANY_DETAILS.directorTitle}</p>
                    <p className="text-slate-500 text-[11px] mt-0.5">
                      Copier Spare Parts Export & International Trade
                    </p>
                  </div>
                </div>

                {/* Phone Numbers with Click-to-Call */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200">
                  <div className="p-2 bg-sky-100 text-sky-700 rounded-lg shrink-0 mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900 mb-1">Direct Calling Lines</h4>
                    <div className="flex flex-col sm:flex-row gap-2">
                      {COMPANY_DETAILS.phones.map((p) => (
                        <a
                          key={p.number}
                          href={`tel:${p.number}`}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:border-blue-400 text-slate-800 hover:text-blue-700 rounded-lg transition-colors font-medium text-xs shadow-2xs"
                        >
                          <Phone className="w-3 h-3 text-blue-600" />
                          <span>{p.label}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                </div>

                {/* WhatsApp Chat Buttons */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200">
                  <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg shrink-0 mt-0.5">
                    <MessageCircle className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900 mb-1">Official WhatsApp Support</h4>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <a
                        href={createWhatsAppUrl('Hello Jayesh Mori, I want to inquire about copier machine spare parts export.', '919082523625')}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors font-medium text-xs shadow-2xs"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Chat +91 90825 23625</span>
                      </a>
                      <a
                        href={createWhatsAppUrl('Hello Jayesh Mori, I need pricing information for copier spare parts.', '917208334310')}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors font-medium text-xs shadow-2xs"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Chat +91 72083 34310</span>
                      </a>
                    </div>
                  </div>
                </div>

                {/* Email Address */}
                <div className="flex items-start gap-3 pt-3 border-t border-slate-200">
                  <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg shrink-0 mt-0.5">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 mb-0.5">Export Inquiries Email</h4>
                    <a
                      href={`mailto:${COMPANY_DETAILS.email}`}
                      className="text-blue-700 hover:underline font-medium break-all"
                    >
                      {COMPANY_DETAILS.email}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Google Maps Location Section */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-slate-900">Kamothe, Navi Mumbai Location</h4>
                  <p className="text-[11px] text-slate-500">Patel Harmony, Sector 20 · Near JNPT Port</p>
                </div>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${COMPANY_DETAILS.googleMapsQuery}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[11px] font-semibold text-blue-700 hover:text-blue-800"
                >
                  <span>Open in Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="aspect-[16/9] w-full bg-slate-200">
                <iframe
                  title="Mori's International Location Map"
                  src={`https://maps.google.com/maps?q=${encodeURIComponent(COMPANY_DETAILS.address.fullAddress)}&t=&z=14&ie=UTF8&iwloc=&output=embed`}
                  className="w-full h-full border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Contact Enquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 bg-slate-50 border border-slate-200 rounded-2xl shadow-2xs">
              <h3 className="text-xl font-bold text-slate-900 mb-1">
                Send an Export Enquiry
              </h3>
              <p className="text-xs text-slate-600 mb-6 leading-relaxed">
                Fill in the form below with your requirements or questions. Director Jayesh Mori reviews and responds to all international business inquiries directly.
              </p>

              {submittedRef ? (
                <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-3">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-bold text-emerald-900">
                    Enquiry Successfully Received
                  </h4>
                  <p className="text-xs text-emerald-700 max-w-md mx-auto">
                    Your inquiry has been registered with Reference ID <strong className="font-mono">{submittedRef}</strong>. We will get back to you promptly with technical specs and quotation details.
                  </p>
                  <button
                    onClick={() => setSubmittedRef(null)}
                    className="mt-3 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {formError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                      {formError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Johnathan Davis"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Company / Business Name
                      </label>
                      <input
                        type="text"
                        placeholder="Prime Digital Solutions Ltd."
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Business Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="info@yourcompany.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        WhatsApp / Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+44 7911 123456"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Destination Country / Delivery City
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. United Arab Emirates, Kenya, South Africa, Germany, USA"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Message / Required Parts & Models
                    </label>
                    <textarea
                      rows={4}
                      required
                      placeholder="List the copier brands, part codes (OPC drums, toner powder, fuser film, blades), and approximate order volume you require..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full px-3 py-2.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-sky-200" />
                    <span>{submitting ? 'Sending Enquiry...' : 'Submit Contact Enquiry'}</span>
                  </button>

                  <div className="pt-2 text-center">
                    <span className="text-[11px] text-slate-500">Or reach Director Jayesh Mori directly:</span>
                    <div className="mt-2 flex justify-center gap-2">
                      <a
                        href={createWhatsAppUrl('Hello Jayesh Mori, I am reaching out from your website for a business inquiry.')}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Chat via WhatsApp (+91 90825 23625)</span>
                      </a>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
