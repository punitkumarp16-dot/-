'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Layers, Disc, Flame, Package, Droplets, Scroll, Sparkles, Sliders, Cpu } from 'lucide-react';
import { ProductCategory } from '@/types';

interface FeaturedCategoriesProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export function FeaturedCategories({ onSelectCategory }: FeaturedCategoriesProps) {
  const categoriesList: Array<{
    name: ProductCategory;
    summary: string;
    highlights: string;
    image: string;
    icon: React.ReactNode;
  }> = [
    {
      name: 'OPC Drums',
      summary: 'Japanese organic photo-conductors with ultra-durable charge transport layers.',
      highlights: 'Long-life optical cylinders · High page yield · No background fog',
      image: '/images/cat_opc_drums_1794149101848.jpg',
      icon: <Disc className="w-5 h-5 text-sky-500" />,
    },
    {
      name: 'Fuser Parts',
      summary: 'High-temperature Teflon heat rollers, silicone pressure rollers, and metallic film sleeves.',
      highlights: 'Upper & lower rollers · Fuser film sleeves · Thermistors & gears',
      image: '/images/cat_fuser_parts_1794149102366.jpg',
      icon: <Flame className="w-5 h-5 text-amber-500" />,
    },
    {
      name: 'Toners & Cartridges',
      summary: 'Micro-refined bulk toner bottles (1kg/10kg) and ready-to-install CMYK cartridges.',
      highlights: 'Monochrome & colour toner · High optical black density · Low waste',
      image: '/images/cat_toner_bottles_1794149102597.jpg',
      icon: <Package className="w-5 h-5 text-blue-500" />,
    },
    {
      name: 'Cleaning Blades',
      summary: 'Laser-cut polyurethane wiper blades with zero-chatter beveled edges.',
      highlights: 'OPC drum cleaning blades · ITB belt blades · Pre-powdered',
      image: '/images/cat_cleaning_blades_1794149102404.jpg',
      icon: <Sparkles className="w-5 h-5 text-emerald-500" />,
    },
    {
      name: 'RC Parts',
      summary: 'Reconditioned laser scanner units, developing units, and precision sub-assemblies.',
      highlights: 'Ultrasonic cleaned · Bench-calibrated · 100% pre-export tested',
      image: '/images/hero_copier_parts_export_1794149100838.jpg',
      icon: <Layers className="w-5 h-5 text-purple-500" />,
    },
    {
      name: 'Paper Feed Rollers',
      summary: 'High-traction natural rubber pickup, feed, and reverse separation rollers.',
      highlights: 'Cassette feed kits · Torque limiters · Anti-slip rubber treads',
      image: '/images/cat_cleaning_blades_1794149102404.jpg',
      icon: <Sliders className="w-5 h-5 text-orange-500" />,
    },
    {
      name: 'Duplicator Inks',
      summary: 'Soy-emulsion digital duplicator ink cartridges for high-speed printing presses.',
      highlights: 'Intense black density · Instant drying · Compatible with RISO & Duplo',
      image: '/images/cat_toner_bottles_1794149102597.jpg',
      icon: <Droplets className="w-5 h-5 text-indigo-500" />,
    },
    {
      name: 'Master Rolls',
      summary: 'Ultra-thin Japanese thermal duplicator master tissue for crisp fine-line resolution.',
      highlights: 'Thermal master tissue · High copy endurance · B4, A3 & A4 roll sizes',
      image: '/images/cat_cleaning_blades_1794149102404.jpg',
      icon: <Scroll className="w-5 h-5 text-teal-500" />,
    },
    {
      name: 'Electronic Parts',
      summary: 'Power boards, DC controller units, clutch gears, sensors, and contact springs.',
      highlights: 'High-voltage power boards · Heavy-duty drive gears · Sensors & chips',
      image: '/images/hero_copier_parts_export_1794149100838.jpg',
      icon: <Cpu className="w-5 h-5 text-rose-500" />,
    },
  ];

  return (
    <section className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">
            Comprehensive Inventory
          </div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
            Featured Product Categories
          </h2>
          <p className="text-sm text-slate-600 mt-2">
            Explore our specialized range of copier replacement components, precision mechanics, and imaging consumables manufactured and export-packaged for international distributors.
          </p>
        </div>

        {/* 9 Categories Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoriesList.map((cat) => (
            <div
              key={cat.name}
              className="group flex flex-col bg-white border border-slate-200 hover:border-blue-400 rounded-xl overflow-hidden transition-all duration-200 hover:shadow-md"
            >
              {/* Category Image thumbnail */}
              <div className="relative aspect-[16/9] w-full bg-slate-100 overflow-hidden">
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  className="object-cover group-hover:scale-103 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 p-2 bg-white/90 backdrop-blur-xs rounded-lg shadow-xs">
                  {cat.icon}
                </div>
              </div>

              {/* Category Details */}
              <div className="p-5 flex flex-col flex-1 justify-between">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    {cat.summary}
                  </p>
                  <div className="mt-3 text-[11px] font-medium text-slate-500 border-t border-slate-100 pt-2">
                    {cat.highlights}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectCategory(cat.name);
                      const el = document.getElementById('products');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="flex items-center gap-1.5 text-xs font-semibold text-blue-700 group-hover:text-blue-800 transition-colors cursor-pointer"
                  >
                    <span>View {cat.name} Catalog</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
