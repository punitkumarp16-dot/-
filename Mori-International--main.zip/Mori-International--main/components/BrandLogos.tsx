'use client';

import React from 'react';
import { CompatibleBrand } from '@/types';
import { COMPANY_DETAILS } from '@/data/company';

interface BrandLogosProps {
  onSelectBrand?: (brand: CompatibleBrand) => void;
}

export function BrandLogos({ onSelectBrand }: BrandLogosProps) {
  // Brand details with descriptive typography & compatibility tag
  const brandProfiles: Array<{ name: CompatibleBrand; description: string; codePrefix: string }> = [
    { name: 'Canon', description: 'imageRUNNER & iR Advance series', codePrefix: 'CAN' },
    { name: 'Ricoh', description: 'Aficio MP & IM high-speed engines', codePrefix: 'RIC' },
    { name: 'Konica Minolta', description: 'bizhub monochrome & colour series', codePrefix: 'KM' },
    { name: 'Kyocera', description: 'TASKalfa & ECOSYS production series', codePrefix: 'KYO' },
    { name: 'Xerox', description: 'WorkCentre, AltaLink & VersaLink', codePrefix: 'XER' },
    { name: 'Toshiba', description: 'e-STUDIO digital multi-function copiers', codePrefix: 'TOS' },
    { name: 'Riso', description: 'RISO EZ, RZ, MZ digital duplicator series', codePrefix: 'RSO' },
    { name: 'Duplo', description: 'DP-S, DP-U, DP-J duplicator master & ink', codePrefix: 'DUP' },
  ];

  return (
    <section id="brands" className="py-12 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-1">
              Cross-Platform Precision Engineering
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Compatible Brands & Machine Series
            </h2>
          </div>
          <p className="text-xs text-slate-500 max-w-md">
            Click any manufacturer to filter our warehouse inventory. Brand names, logos, and model numbers are referenced solely for compatibility identification.
          </p>
        </div>

        {/* 8-Brand Interactive Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
          {brandProfiles.map((brand) => (
            <button
              key={brand.name}
              type="button"
              onClick={() => {
                if (onSelectBrand) {
                  onSelectBrand(brand.name);
                  const el = document.getElementById('products');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="flex flex-col items-center justify-center p-4 bg-white hover:bg-blue-50/50 border border-slate-200 hover:border-blue-400 rounded-xl transition-all duration-200 group text-center cursor-pointer shadow-2xs hover:shadow-sm"
              title={`View compatible spare parts for ${brand.name}`}
            >
              <span className="font-extrabold text-sm sm:text-base tracking-wider text-slate-800 group-hover:text-blue-700 transition-colors uppercase">
                {brand.name}
              </span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-600 mt-1 line-clamp-1">
                {brand.description}
              </span>
            </button>
          ))}
        </div>

        {/* Legal Non-Affiliation Disclaimer */}
        <div className="mt-6 pt-4 border-t border-slate-200/80 text-[11px] text-slate-400 text-center leading-relaxed">
          <strong>Compatibility Disclaimer:</strong> All registered trademarks, brand names, product model designations, and logos (including CANON, RICOH, KONICA MINOLTA, KYOCERA, XEROX, TOSHIBA, RISO, and DUPLO) are the property of their respective owners. Their use on this website is strictly descriptive to indicate parts compatibility for repair, maintenance, and replacement purposes. MORI’S INTERNATIONAL is an independent spare parts manufacturer and exporter and does not claim any official affiliation with or authorization by these OEMs.
        </div>
      </div>
    </section>
  );
}
