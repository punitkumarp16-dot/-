'use client';

import React from 'react';
import Image from 'next/image';
import { UserCheck, Compass, Anchor, MapPin, Phone, Mail, Award, CheckCircle } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

export function AboutUs() {
  return (
    <section id="about" className="py-16 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">
            Company Profile & Leadership
          </div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
            About MORI’S INTERNATIONAL
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            A dedicated copier machine spare parts manufacturer and exporter based in Navi Mumbai, India, delivering precision printing components to international markets.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Company Overview & Business Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
              <h3 className="text-lg font-bold text-slate-900">
                Company Overview & Core Mission
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                <strong>MORI’S INTERNATIONAL</strong> is a specialized manufacturer and exporter of commercial copier machine spare parts, laser printer components, and imaging consumables. Headquartered in Kamothe, Navi Mumbai (Maharashtra, India), we cater to global importers, wholesale distributors, copier leasing companies, and service reconditioning centers.
              </p>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Under the proactive leadership of <strong>Director Jayesh Mori</strong>, our operations are centered on providing reliable, high-yield replacement parts that match OEM specifications without the prohibitive cost barriers of proprietary brands.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
                <div className="flex items-start gap-2.5">
                  <UserCheck className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Director: Jayesh Mori</h4>
                    <p className="text-[11px] text-slate-500">
                      Direct executive oversight on manufacturing standards, pricing, and international client relationships.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Anchor className="w-4 h-4 text-sky-600 mt-0.5 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Strategic JNPT Port Hub</h4>
                    <p className="text-[11px] text-slate-500">
                      Located minutes away from Nhava Sheva (JNPT) container terminal, enabling expedited ocean freight worldwide.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Business Philosophy & Quality Commitment */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs">
                  <Compass className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">Business Philosophy</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  We believe in long-term B2B relationships rooted in honest specifications, transparent FOB/CIF pricing, and consistent batch quality. We treat every overseas shipment with the diligence required for seamless customs clearance.
                </p>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-2">
                <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
                  <Award className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-900">Quality Commitment</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Every product line—from organic photoconductor (OPC) drums to Teflon fuser rollers and micro-fine toner powder—undergoes electrical charge testing and dimensional tolerances to ensure zero machine damage.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Authentic Visual Credentials & Visiting Card */}
          <div className="lg:col-span-5 space-y-5">
            {/* Authentic Company Offerings Visual Card */}
            <div className="bg-slate-900 text-white rounded-2xl overflow-hidden border border-slate-800 shadow-md">
              <div className="relative aspect-[16/9] w-full bg-slate-950">
                <Image
                  src={COMPANY_DETAILS.cardImages.offeringsCard}
                  alt="Mori's International Key Offerings card"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-4 text-xs space-y-1">
                <span className="text-[10px] uppercase tracking-wider text-sky-400 font-semibold block">
                  Official Company Presentation
                </span>
                <p className="text-slate-300">
                  Global Shipping & Manufacturing Portfolio verified for copier spares, toner powder, and toner cartridges.
                </p>
              </div>
            </div>

            {/* Authentic Visiting Card Card */}
            <div className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs">
              <div className="relative aspect-[16/9] w-full bg-slate-100">
                <Image
                  src={COMPANY_DETAILS.cardImages.businessCard}
                  alt="Jayesh Mori Director Business Card"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-4 space-y-2 text-xs">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div>
                    <h4 className="font-bold text-slate-900">Jayesh Mori</h4>
                    <span className="text-slate-500 text-[11px]">Director · MORI’S INTERNATIONAL</span>
                  </div>
                  <a
                    href="tel:+919082523625"
                    className="px-3 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-md font-medium text-[11px] transition-colors"
                  >
                    Direct Call
                  </a>
                </div>

                <div className="space-y-1 text-slate-600 text-[11px]">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>Shop No. 1-2-3, Patel Harmony, Sector 20, Kamothe, Navi Mumbai</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Anchor className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                    <span>Near Nhava Sheva (JNPT) Port, Maharashtra, India. PIN: 410209</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
