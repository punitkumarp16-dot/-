'use client';

import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { MapPin, Phone, Mail, MessageCircle, ExternalLink, Shield, FileCheck } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

interface FooterProps {
  onSelectCategory?: (category: string) => void;
}

export function Footer({ onSelectCategory }: FooterProps) {
  const [modalType, setModalType] = useState<'privacy' | 'terms' | null>(null);

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 text-xs">
      {/* Upper Footer: Brand, Quick Links, Categories, Contact */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Brand & Overview (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <BrandLogo variant="light" size="lg" showTagline={false} />
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              <strong>MORI’S INTERNATIONAL</strong> is a premier manufacturer and exporter of copier machine spare parts, laser printer components, and consumable supplies based in Navi Mumbai, India, near Nhava Sheva (JNPT) container port.
            </p>
            <div className="text-[11px] text-slate-400 space-y-1">
              <p><strong className="text-slate-200">Director:</strong> {COMPANY_DETAILS.director}</p>
              <p><strong className="text-slate-200">Key Offerings:</strong> Copier Spare Parts · Toner Powder · Cartridges · Copier Machines</p>
              <p><strong className="text-slate-200">Logistics Hub:</strong> Near JNPT Port, Nhava Sheva, Maharashtra</p>
            </div>
            {/* WhatsApp Quick Button */}
            <div className="pt-1">
              <a
                href={createWhatsAppUrl('Hello Jayesh Mori, I am inquiring about copier spare parts export.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-medium text-xs transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp: +91 90825 23625</span>
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Quick Navigation
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="#products" className="hover:text-white transition-colors">Product Catalogue</a>
              </li>
              <li>
                <a href="#brands" className="hover:text-white transition-colors">Compatible Brands</a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-white transition-colors">Why Choose Us</a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">About MORI’S</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-white transition-colors">Contact & Location</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Product Categories (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Product Categories
            </h4>
            <ul className="space-y-2">
              {COMPANY_DETAILS.categories.map((cat) => (
                <li key={cat}>
                  <button
                    type="button"
                    onClick={() => {
                      if (onSelectCategory) {
                        onSelectCategory(cat);
                        const el = document.getElementById('products');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="text-left text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact & Office (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Export Office & Warehouse
            </h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>
                  Shop No. 1-2-3, Patel Harmony, Plot No. 23, Sector 20, Kamothe, Panvel, Navi Mumbai – 410209, India.
                </span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-sky-400 shrink-0" />
                <span>+91 90825 23625 / +91 7208334310</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                <a href={`mailto:${COMPANY_DETAILS.email}`} className="hover:text-white transition-colors">
                  {COMPANY_DETAILS.email}
                </a>
              </p>
            </div>
          </div>
        </div>

        {/* Disclaimer row */}
        <div className="mt-12 pt-6 border-t border-slate-900 text-[11px] text-slate-500 leading-relaxed">
          <p>
            <strong>Trademark & Brand Notice:</strong> All brand names, model numbers, and manufacturer trademarks (Canon, Ricoh, Konica Minolta, Kyocera, Xerox, Toshiba, Riso, Duplo) appearing on this website are registered trademarks of their respective corporations. They are referenced strictly for compatibility identification and parts replacement reference. MORI’S INTERNATIONAL is an independent spare parts manufacturer and exporter.
          </p>
        </div>
      </div>

      {/* Bottom Legal Bar */}
      <div className="bg-black/50 border-t border-slate-900 py-4 px-4 sm:px-6 lg:px-8 text-[11px] text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            © {new Date().getFullYear()} MORI’S INTERNATIONAL. All rights reserved. Directed by Jayesh Mori.
          </p>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setModalType('privacy')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span>·</span>
            <button
              onClick={() => setModalType('terms')}
              className="hover:text-slate-300 transition-colors cursor-pointer"
            >
              Terms & Conditions
            </button>
          </div>
        </div>
      </div>

      {/* Legal Information Modal */}
      {modalType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white text-slate-900 rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                {modalType === 'privacy' ? <Shield className="w-5 h-5 text-blue-600" /> : <FileCheck className="w-5 h-5 text-blue-600" />}
                <span>{modalType === 'privacy' ? 'Privacy Policy' : 'Terms & Export Conditions'}</span>
              </h3>
              <button
                onClick={() => setModalType(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg text-sm"
              >
                ✕
              </button>
            </div>

            <div className="py-4 text-xs text-slate-600 space-y-3 leading-relaxed">
              {modalType === 'privacy' ? (
                <>
                  <p>
                    <strong>MORI’S INTERNATIONAL</strong> is committed to safeguarding the privacy and business confidentiality of our international trade partners, distributors, and inquiry submitters.
                  </p>
                  <p>
                    <strong>Information Collection:</strong> We collect contact details (name, company name, email, phone/WhatsApp number, destination port, and parts requests) solely for the purpose of drafting quotations, shipping logistics, and customer support.
                  </p>
                  <p>
                    <strong>Confidentiality:</strong> We do not sell, rent, or share customer inquiries or product requirement lists with unauthorized third parties.
                  </p>
                  <p>
                    For inquiries regarding data privacy, please contact: <strong>morisinternationalindia@gmail.com</strong>.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    <strong>Export Quotations:</strong> All price quotes issued by MORI’S INTERNATIONAL are valid for the timeframe stated on the official proforma invoice and are subject to market commodity fluctuations for metals, chemicals, and ocean freight.
                  </p>
                  <p>
                    <strong>Shipping & Delivery Terms:</strong> Shipments are commonly offered on FOB Nhava Sheva (JNPT) Port or CIF to client-designated seaport or airport. Custom clearance at the destination country remains the responsibility of the importing party unless specified.
                  </p>
                  <p>
                    <strong>Compatibility:</strong> Replacement parts are manufactured to fit designated copier and duplicator models. Buyers are encouraged to review model compatibility prior to final shipment dispatch.
                  </p>
                </>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setModalType(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}
