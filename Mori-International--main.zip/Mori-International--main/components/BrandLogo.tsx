import React from 'react';

interface BrandLogoProps {
  variant?: 'dark' | 'light';
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export function BrandLogo({ variant = 'dark', size = 'md', showTagline = false }: BrandLogoProps) {
  const isLight = variant === 'light';

  const sphereSizes = {
    sm: 'w-2 h-2',
    md: 'w-2.5 h-2.5',
    lg: 'w-3.5 h-3.5',
  };

  const titleSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div className="flex items-center gap-2.5 shrink-0 select-none">
      {/* Authentic 3-Sphere Triad (Cyan, Magenta, Yellow) from Mori's International identity */}
      <div className="relative flex flex-col items-center justify-center shrink-0">
        {/* Top: Cyan Sphere */}
        <span
          className={`${sphereSizes[size]} rounded-full bg-gradient-to-tr from-sky-600 to-cyan-400 shadow-sm`}
          title="Cyan"
        />
        {/* Bottom Pair: Magenta & Yellow */}
        <div className="flex items-center gap-1 -mt-0.5">
          <span
            className={`${sphereSizes[size]} rounded-full bg-gradient-to-tr from-pink-600 to-rose-400 shadow-sm`}
            title="Magenta"
          />
          <span
            className={`${sphereSizes[size]} rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 shadow-sm`}
            title="Yellow"
          />
        </div>
      </div>

      <div className="flex flex-col">
        <div className="flex items-baseline gap-1.5 leading-none">
          <span className={`font-bold tracking-tight font-sans ${titleSizes[size]} ${isLight ? 'text-white' : 'text-slate-900'}`}>
            Mori’s
          </span>
          <span
            className={`font-semibold tracking-wider uppercase text-[10px] md:text-xs ${
              isLight ? 'text-sky-300' : 'text-blue-700'
            }`}
          >
            INTERNATIONAL
          </span>
        </div>
        {showTagline && (
          <span className={`text-[10px] tracking-tight mt-0.5 ${isLight ? 'text-slate-300' : 'text-slate-500'}`}>
            Copier Machine Spare Parts Manufacturer & Exporter
          </span>
        )}
      </div>
    </div>
  );
}
