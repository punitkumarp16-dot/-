'use client';

import React, { useState, useEffect } from 'react';
import { ShieldCheck, RefreshCw, X, MessageSquare, Phone, Mail, MapPin, Package, Clock } from 'lucide-react';
import { EnquirySubmission } from '@/types';
import { createWhatsAppUrl } from '@/data/company';

interface EnquiriesViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EnquiriesViewer({ isOpen, onClose }: EnquiriesViewerProps) {
  const [enquiries, setEnquiries] = useState<EnquirySubmission[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchEnquiries = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/enquiries');
      const data = await res.json();
      if (data.success) {
        setEnquiries(data.enquiries || []);
      } else {
        setError('Failed to load enquiries');
      }
    } catch {
      setError('Error connecting to backend database');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    if (isOpen) {
      fetch('/api/enquiries')
        .then((res) => res.json())
        .then((data) => {
          if (active && data.success) {
            setEnquiries(data.enquiries || []);
          }
        })
        .catch(() => {
          if (active) setError('Failed to load enquiries');
        });
    }
    return () => {
      active = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="font-bold text-sm">
                Director Management: RFQ & Enquiries Database
              </h3>
              <p className="text-[11px] text-slate-400">
                Persistent storage of inbound quotation requests for Jayesh Mori
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={fetchEnquiries}
              disabled={loading}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg transition-colors"
              title="Refresh database"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {loading && (
            <div className="text-center py-8 text-xs text-slate-500">
              Loading saved inquiries from backend...
            </div>
          )}

          {error && (
            <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200">
              {error}
            </div>
          )}

          {!loading && enquiries.length === 0 && (
            <div className="text-center py-12 text-slate-500 text-xs space-y-2">
              <Package className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="font-medium text-slate-700">No inquiries recorded yet.</p>
              <p className="text-slate-400">
                Submit an inquiry via the &ldquo;Request Quote&rdquo; drawer or contact form to see it logged here in real-time.
              </p>
            </div>
          )}

          {!loading && enquiries.length > 0 && (
            <div className="space-y-3">
              <div className="text-xs text-slate-500 font-medium">
                Total Inquiries in Database: <strong className="text-slate-900 font-mono">{enquiries.length}</strong>
              </div>

              {enquiries.map((enq) => (
                <div
                  key={enq.id}
                  className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-blue-700">{enq.id}</span>
                      <span className="text-[11px] text-slate-400">·</span>
                      <span className="font-semibold text-slate-800">{enq.customerName}</span>
                      {enq.companyName && (
                        <span className="text-slate-500">({enq.companyName})</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{new Date(enq.createdAt).toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-600">
                    <div className="flex items-center gap-1.5 truncate">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <a href={`mailto:${enq.email}`} className="text-blue-700 hover:underline truncate">
                        {enq.email}
                      </a>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <a href={`tel:${enq.phone}`} className="hover:text-slate-900">
                        {enq.phone}
                      </a>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{enq.country || 'International'}</span>
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-700">
                    <strong>Shipping Term:</strong> {enq.shippingTerm}
                  </div>

                  {enq.items && enq.items.length > 0 && (
                    <div className="p-2.5 bg-white border border-slate-200 rounded-lg space-y-1">
                      <div className="text-[11px] font-bold text-slate-800 uppercase">
                        Requested Items ({enq.items.length}):
                      </div>
                      <div className="space-y-1">
                        {enq.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between text-[11px] text-slate-600">
                            <span>
                              <span className="font-mono text-slate-700 font-semibold">{it.code}</span> · {it.name} ({it.brand})
                            </span>
                            <span className="font-bold text-slate-800 tabular-nums">Qty: {it.quantity}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {enq.message && (
                    <div className="p-2.5 bg-blue-50/50 border border-blue-100 rounded-lg text-[11px] text-slate-700">
                      <strong>Buyer Note:</strong> {enq.message}
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-1">
                    <a
                      href={createWhatsAppUrl(`Hello ${enq.customerName}, this is Jayesh Mori from MORI'S INTERNATIONAL regarding your quotation inquiry ${enq.id}.`, enq.phone.replace(/[^0-9]/g, ''))}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-medium rounded-md transition-colors"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>Reply on WhatsApp</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-right">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
}
