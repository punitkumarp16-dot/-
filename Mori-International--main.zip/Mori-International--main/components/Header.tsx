'use client';

import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import { Phone, MessageCircle, Menu, X, FileText } from 'lucide-react';
import { COMPANY_DETAILS, createWhatsAppUrl } from '@/data/company';

interface HeaderProps {
  quoteCount: number;
  onOpenQuote: () => void;
  activeSection?: string;
}

export function Header({ quoteCount, onOpenQuote }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Products', href: '#products' },
    { label: 'Compatible Brands', href: '#brands' },
    { label: 'Why Choose Us', href: '#why-us' },
    { label: 'About Us', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Notification Bar with Export Hub & Instant WhatsApp */}
      <div className="bg-slate-900 text-slate-200 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="text-amber-400 font-medium">Export Advantage:</span>
            <span className="hidden sm:inline text-slate-300">
              Near Nhava Sheva (JNPT) Container Port, Navi Mumbai · Worldwide Ocean & Air Freight
            </span>
            <span className="sm:hidden text-slate-300">Nhava Sheva (JNPT) Export Hub</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="tel:+919082523625"
              className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-sky-400" />
              <span>+91 90825 23625</span>
            </a>
            <span className="text-slate-600">|</span>
            <a
              href={createWhatsAppUrl('Hello Jayesh Mori, I would like to inquire about copier spare parts.')}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span className="hidden md:inline">WhatsApp Chat</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Top Bar strictly fulfilling 3-Zone Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5">
          {/* Zone 1: Single Brand element */}
          <a href="#" className="whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded">
            <BrandLogo size="md" />
          </a>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-700">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="whitespace-nowrap shrink-0 hover:text-blue-700 transition-colors py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenQuote}
              type="button"
              className="flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-sm transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 whitespace-nowrap shrink-0"
              aria-label="View quotation request"
            >
              <FileText className="w-4 h-4 text-sky-200" />
              <span>Request Quote</span>
              {quoteCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-amber-400 text-slate-900 text-xs font-bold rounded-full">
                  {quoteCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="lg:hidden p-2 text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-slate-200 px-6 py-4 space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block py-2 text-base font-medium text-slate-800 hover:text-blue-700 border-b border-slate-100 last:border-0"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 flex flex-col gap-2">
              <a
                href={createWhatsAppUrl('Hello Jayesh Mori, I need pricing for copier machine spare parts.')}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 text-white text-sm font-medium rounded-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp (+91 90825 23625)</span>
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
