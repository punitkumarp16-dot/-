export interface Product {
  id: string;
  name: string;
  code: string;
  category: ProductCategory;
  brand: CompatibleBrand;
  compatibleModels: string[];
  description: string;
  keyFeatures: string[];
  packaging: string;
  moq: string;
  image: string;
  status: 'In Stock' | 'Export Ready' | 'Made to Order';
}

export type ProductCategory =
  | 'RC Parts'
  | 'Toners & Cartridges'
  | 'Duplicator Inks'
  | 'Master Rolls'
  | 'OPC Drums'
  | 'Cleaning Blades'
  | 'Fuser Parts'
  | 'Paper Feed Rollers'
  | 'Electronic Parts';

export type CompatibleBrand =
  | 'Canon'
  | 'Ricoh'
  | 'Konica Minolta'
  | 'Kyocera'
  | 'Xerox'
  | 'Toshiba'
  | 'Riso'
  | 'Duplo';

export interface QuoteItem {
  product: Product;
  quantity: number;
  notes?: string;
}

export interface EnquirySubmission {
  id: string;
  customerName: string;
  companyName: string;
  email: string;
  phone: string;
  country: string;
  shippingTerm: 'FOB Nhava Sheva (JNPT)' | 'CIF (Destination Port)' | 'Air Express' | 'Domestic Supply (India)';
  message: string;
  items: Array<{
    code: string;
    name: string;
    brand: string;
    quantity: number;
  }>;
  createdAt: string;
  status: 'New' | 'Under Review' | 'Quotation Sent';
}
