export const COMPANY_DETAILS = {
  name: "Mori's International",
  legalName: "MORI'S INTERNATIONAL",
  tagline: "Copier Machine Spare Parts Manufacturer & Exporter",
  director: "Jayesh Mori",
  directorTitle: "Director",
  headline: "Your Trusted Partner in Copier Machine Spare Parts",
  subheading: "Quality Products, Reliable Supply and Global Business Solutions.",
  address: {
    line1: "Shop No. 1-2-3, Patel Harmony",
    line2: "Plot No. 23, Sector 20, Kamothe, Panvel",
    city: "Navi Mumbai",
    state: "Maharashtra",
    country: "India",
    zip: "410209",
    landmark: "Near Nhava Sheva (JNPT) Port, India",
    fullAddress: "Shop No. 1-2-3, Patel Harmony, Plot No. 23, Sector 20, Kamothe, Panvel, Navi Mumbai, Maharashtra, India. PIN: 410209",
  },
  phones: [
    { label: "+91 90825 23625", number: "+919082523625", primary: true },
    { label: "+91 72083 34310", number: "+917208334310", primary: false },
  ],
  whatsappNumbers: [
    { label: "+91 90825 23625", number: "919082523625", isPrimary: true },
    { label: "+91 72083 34310", number: "917208334310", isPrimary: false },
  ],
  email: "morisinternationalindia@gmail.com",
  exportHub: "Nhava Sheva (JNPT) Container Port, Mumbai, India",
  googleMapsQuery: "Patel+Harmony+Sector+20+Kamothe+Navi+Mumbai+410209",
  cardImages: {
    offeringsCard: "/assets/aistudio/IMG-20261108-WA0023_29270622.jpg",
    businessCard: "/assets/aistudio/IMG-20261108-WA0025_6299d0b8.jpg",
  },
  keyOfferings: [
    "Copier Machine Spare Parts",
    "Toner Powder (Colour & Monochrome)",
    "Toner Cartridges",
    "Copier Machines",
  ],
  compatibleBrands: [
    "Canon",
    "Ricoh",
    "Konica Minolta",
    "Kyocera",
    "Xerox",
    "Toshiba",
    "Riso",
    "Duplo",
  ] as const,
  categories: [
    "RC Parts",
    "Toners & Cartridges",
    "Duplicator Inks",
    "Master Rolls",
    "OPC Drums",
    "Cleaning Blades",
    "Fuser Parts",
    "Paper Feed Rollers",
    "Electronic Parts",
  ] as const,
};

export const createWhatsAppUrl = (message: string, phone: string = "919082523625") => {
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
};
