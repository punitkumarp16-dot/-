import fs from 'fs';
import path from 'path';
import { EnquirySubmission } from '@/types';

const ENQUIRIES_FILE = path.join(process.cwd(), 'data', 'enquiries.json');

// In-memory fallback in case of read-only filesystems
let memoryEnquiries: EnquirySubmission[] = [];

export function getEnquiries(): EnquirySubmission[] {
  try {
    if (fs.existsSync(ENQUIRIES_FILE)) {
      const data = fs.readFileSync(ENQUIRIES_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error reading enquiries file:', err);
  }
  return memoryEnquiries;
}

export function saveEnquiry(enquiry: EnquirySubmission): boolean {
  try {
    const existing = getEnquiries();
    const updated = [enquiry, ...existing];
    memoryEnquiries = updated;

    const dataDir = path.dirname(ENQUIRIES_FILE);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(ENQUIRIES_FILE, JSON.stringify(updated, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error saving enquiry to file:', err);
    memoryEnquiries.unshift(enquiry);
    return true; // memory fallback successful
  }
}
